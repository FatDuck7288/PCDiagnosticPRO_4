namespace PCDiagnosticPro.Models
{
    public class ResultField
    {
        public string Key { get; set; } = string.Empty;
        public string Value { get; set; } = "Non disponible";
    }
}
