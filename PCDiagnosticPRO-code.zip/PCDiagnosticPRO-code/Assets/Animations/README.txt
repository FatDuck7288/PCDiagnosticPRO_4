Speed Test - Icône planète
==========================
• earth-globe.png : image statique de la Terre (couleur, type globe 3D). Affichée à côté de "Speed Test Réseau" et animée en rotation pendant le scan ou le test. Nom exact requis : earth-globe.png
• planet.gif : (optionnel) GIF animé. Si présent, peut être utilisé pour une animation avancée.

Si aucun PNG n'est présent, l'application affiche l'emoji globe (fallback).
